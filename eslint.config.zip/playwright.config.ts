import { defineConfig } from '@playwright/test';

// Локально используем системный браузер (Edge есть на любой Windows; CDN Playwright может быть недоступен).
// В CI (GitHub Actions) ставится свой Chromium — там переменная CI задана.
const local = !process.env.CI;

export default defineConfig({
  testDir: 'tests/e2e',
  timeout: 30_000,
  use: {
    baseURL: 'http://localhost:4173',
    headless: true,
    ...(local ? { channel: process.env.PW_CHANNEL ?? 'msedge' } : {}),
  },
  webServer: { command: 'npm run preview', port: 4173, reuseExistingServer: true },
});
