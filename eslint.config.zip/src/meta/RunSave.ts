import type { RunSave } from '../run/RunState';

const KEY = 'arkfall.run.v1';

export function loadRun(): RunSave | null {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return null;
    const s = JSON.parse(raw) as RunSave;
    return s.v === 1 ? s : null;
  } catch { return null; }
}
export function saveRun(s: RunSave) { try { localStorage.setItem(KEY, JSON.stringify(s)); } catch { /* best effort */ } }
export function clearRun() { try { localStorage.removeItem(KEY); } catch { /* best effort */ } }
